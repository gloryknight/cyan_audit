SELECT cyanaudit.fn_verify_active_partition();
