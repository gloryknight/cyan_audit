SET client_min_messages TO warning;

DROP FUNCTION IF EXISTS cyanaudit.fn_verify_partition_config(varchar);
